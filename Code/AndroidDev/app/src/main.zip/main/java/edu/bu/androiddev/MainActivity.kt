package edu.bu.androiddev

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import edu.bu.androiddev.components.Navigation
import edu.bu.androiddev.page.Page
import edu.bu.androiddev.ui.theme.AndroidDevTheme

class MainActivity() : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        var page: Page = Page();
        super.onCreate(savedInstanceState)
        setContent {
            AndroidDevTheme {
                page.render()
//                Navigation()
            }

        }
    }
}

@Composable
fun Greeting(name: String) {

}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    AndroidDevTheme {
        Greeting("Android")
    }
}