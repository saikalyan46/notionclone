package edu.bu.androiddev.model

import androidx.compose.runtime.Composable

interface Node {
    fun dataStore():Boolean

    @Composable
    open fun render():Unit

}