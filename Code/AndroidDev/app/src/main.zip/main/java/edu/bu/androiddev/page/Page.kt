package edu.bu.androiddev.page

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import edu.bu.androiddev.components.NodeTextField
import edu.bu.androiddev.model.Node
import kotlinx.coroutines.launch

open class Page {
    @SuppressLint("UnrememberedMutableState")
    @OptIn(ExperimentalMaterialApi::class)
    @Composable
    fun render(){

        val drawerState = rememberBottomDrawerState(BottomDrawerValue.Closed)
        var nodeList = mutableStateListOf<Node>();
        val scope = rememberCoroutineScope()
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(onClick = {scope.launch {
                    drawerState.open()
                }}) {
                    Icon(Icons.Filled.Add,"")
                }
            },
        ) {
            // A surface container using the 'background' color from the theme
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colors.background,
//                onClick = {
//                    if(nodeList.size!=0){
//                        var tmp = nodeList[nodeList.size-1]
//                        if(tmp is NodeTextField) {
//                            tmp.focusRequester.requestFocus()
//                        }
//                    }else{
//                        var temp = NodeTextField()
//                        nodeList.add(temp)
////                        temp.focusRequester.requestFocus()
//                    }
//                }
            ) {
                Column(
                    modifier = Modifier
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Text(
                            text = "Start"
                        )
                        Text(text = "dasdasd")
                        Text(
                            text = "Center"
                        )
                        Text(
                            text = "End",
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                    }
                    Divider(thickness = 1.dp, color = Color.DarkGray)
                    displayNodes(nodeList = nodeList)
                    Box(
                        modifier = Modifier.height(500.dp).fillMaxWidth()
                    ){}
                }
                BottomDrawer(drawerState = drawerState,
                    drawerContent = {
                        // add your UI code
                        Button(
                            onClick = {
                                nodeList.add(NodeTextField())
                                scope.launch {
                                    drawerState.close();
                                }
                            },
                            modifier = Modifier.height(40.dp).fillMaxWidth()
                        ) {
                            Text(text = "Text Field")
                        }
                        Divider()
                        Button(
                            onClick = {
//                        nodeList.add(NodeTextField())
                            },
                            modifier = Modifier.height(40.dp).fillMaxWidth()
                        ) {
                            Text(text = "Text Field")
                        }
                    },
                    gesturesEnabled = drawerState.isOpen,
                    scrimColor = if (!drawerState.isOpen) Color.Unspecified else Color(0.4f,0.4f,0.4f,0.6f)
                ){}
            }

//            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
//                ModalDrawer(
//                    drawerState = drawerState,
//                    gesturesEnabled = false,
//                    drawerContent = {
//                        // Drawer content
//                        Button(
//                            onClick = {
//                                nodeList.add(NodeTextField())
//                                scope.launch {
//                                    drawerState.close();
//                                }
//                            },
//                            modifier = Modifier.height(40.dp).fillMaxWidth()
//                        ) {
//                            Text(text = "Text Field")
//                        }
//                        Divider()
//                        Button(
//                            onClick = {
////                        nodeList.add(NodeTextField())
//                            },
//                            modifier = Modifier.height(40.dp).fillMaxWidth()
//                        ) {
//                            Text(text = "Text Field")
//                        }
//                    }
//                ) {
//
//                }
//            }
        }

    }

    @Composable
    fun displayNodes(nodeList: SnapshotStateList<Node>){
        Column(modifier = Modifier.padding(top = 10.dp)) {
            nodeList.map { it.render() }
        }
    }
}
