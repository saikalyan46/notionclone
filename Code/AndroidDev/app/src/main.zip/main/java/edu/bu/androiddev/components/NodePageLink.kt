package edu.bu.androiddev.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import edu.bu.androiddev.model.Node

class NodePageLink(var name:String): Node {
    lateinit var text:MutableState<String>
    lateinit var focusRequester:FocusRequester

    override fun dataStore(): Boolean {
        TODO("Not yet implemented")
    }

    @OptIn(ExperimentalComposeUiApi::class)
    @Composable
    override fun render():Unit {
        focusRequester = FocusRequester()
        text = remember { mutableStateOf("") }
//        focusRequester = FocusRequester()
//        BasicTextField(value = text.value, onValueChange = { str: String -> text.value = str },
//            textStyle = TextStyle(color = Color.LightGray),
//            cursorBrush = Brush.verticalGradient(0f to Color.LightGray, 1f to Color.LightGray),
//            modifier = Modifier.focusRequester(focusRequester).fillMaxWidth()
//        )
        Row(modifier = Modifier.height(IntrinsicSize.Max)) {
            Box(modifier = Modifier
                .width(30.dp)) {
                Column(modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.AccountBox,"")
                }

            }
            ClickableText(text= AnnotatedString(name),
                modifier = Modifier
                    .focusRequester(focusRequester)
                    .fillMaxWidth(),
                onClick = {
                    // TODO redirect page
                }
//                    .onKeyEvent {
//                            event: KeyEvent ->
//                        // handle backspace key
//                        if (event.type == KeyEventType.KeyUp &&
//                            event.key == Key.Backspace &&
//                            text.value.isEmpty()
//                        // also any additional checks of the "list" i.e isNotEmpty()
//                        ) {
//                            // TODO remove from list
//                            return@onKeyEvent true
//                        }
//                        false
//                    }

            )
//            OutlinedTextField(value = text.value, onValueChange = { str:String-> text.value = str }, modifier = Modifier
//                .fillMaxWidth()
//                .focusRequester(focusRequester))
        }

//        TextField(value = text.value, onValueChange = { str:String-> text.value = str })
//        Text(text = text.value)
    }

}